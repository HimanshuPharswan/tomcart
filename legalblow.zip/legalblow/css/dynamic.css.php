<?php
/**
 * LegalBlow : Dynamic CSS Stylesheet
 *
 */


function legalblow_dynamic_css_stylesheet() {

    $logo_widths= get_theme_mod('legalblow_logo_widths_settings',180);
    $logo_mobile_widths= get_theme_mod('legalblow_logo_width_mobile_settings',180);
    $logo_spacing= get_theme_mod('legalblow_logo_spacing_settings',12);

    $link_color= sanitize_hex_color(get_theme_mod( 'legalblow_link_color','#555' ));
    $link_hover_color= sanitize_hex_color(get_theme_mod( 'legalblow_link_hover_color','#000' ));
    $heading_color= sanitize_hex_color(get_theme_mod( 'legalblow_headings_title_color','#000' ));
	$single_post_width= absint(get_theme_mod( 'legalblow_single_post_width',65));

    $menu_item_spacing= get_theme_mod('legalblow_menu_items_spacing',16);
    $margin_top= get_theme_mod('legalblow_menu_spacing_from_top',0);
    $margin_bottom= get_theme_mod('legalblow_menu_spacing_from_bottom',0);
    $vertical_spacing= get_theme_mod('legalblow_header_toggle_menu_spacing',0);
    $button_height= get_theme_mod('legalblow_header_toggle_menu_btn_height',2);
    $button_padding= get_theme_mod('legalblow_header_toggle_menu_btn_padding',2);
    $button_bg_color= sanitize_hex_color(get_theme_mod( 'legalblow_header_menu_last_button_bg_color','#555' ));
    $button_text_color= sanitize_hex_color(get_theme_mod( 'legalblow_header_menu_last_button_content_color','#c29852' ));
    $button_hover_bg_color= sanitize_hex_color(get_theme_mod( 'legalblow_header_menu_last_button_hover_bg_color','#c29852' ));    

    $site_menu_color= sanitize_hex_color(get_theme_mod( 'legalblow_site_menu_color','#ffffff' ));
    $site_menu_hover_color= sanitize_hex_color(get_theme_mod( 'legalblow_site_menu_hover_color','#0A0000' ));

    $layout_content_width= get_theme_mod( 'legalblow_layout_content_width_settings','1170');

    //breadcrumb
    $page_background_breadcrumbs_color= sanitize_hex_color(get_theme_mod( 'legalblow_page_title_bg_color','#9728ff' ));
    $page_title_breadcrumbs_color= sanitize_hex_color(get_theme_mod( 'legalblow_page_title_color','#ffffff' ));

    //Page title spacing
    $page_title_spacing_top= absint(get_theme_mod( 'legalblow_page_title_spacing_top','70' ));    
    $page_title_spacing_bottom= absint(get_theme_mod( 'legalblow_page_title_spacing_bottom','70' ));        
    $page_content_spacing_top_title= absint(get_theme_mod( 'legalblow_page_content_spacing_top_title','70' ));    

    $footer_copyright_text= get_theme_mod('legalblow_footer_copyrights_spacing',30);

    $footer_bg_color= sanitize_hex_color(get_theme_mod( 'legalblow_footer_bg_color','#397B7E' ));
    $footer_content_color= sanitize_hex_color(get_theme_mod( 'legalblow_footer_content_color','#ffffff' ));
    $footer_links_color= sanitize_hex_color(get_theme_mod( 'legalblow_footer_links_color','#ffffff' ));
    
    $footer_section_spacing= get_theme_mod('legalblow_footer_section_spacing',0);
    $footer_column_spacing= get_theme_mod('legalblow_footer_column_spacing',0);

    $css = '


    a{
        color: ' . $link_color . ';
        text-decoration: none;
        transition: all 0.3s ease-in-out;
    }

    .logo a.custom-logo-link {
        width: ' . $logo_widths . 'px;
        margin: ' . $logo_spacing .'px 0;
        display: inline-block;
    }
    .logo-shifted a.custom-logo-link img{
        width: ' . $logo_mobile_widths . 'px;
    }

    .top-menu .navigation > li > a{
        margin-right: '. $menu_item_spacing . 'px;
        margin-top: '. $margin_top . 'px;
        margin-bottom: '. $margin_bottom . 'px;
    }

    a:hover,a:focus{
        color: ' . $link_hover_color . ';
        text-decoration: none;
        transition: all 0.3s ease-in-out;
    }

    h1,h2,h3,h4,h5,h6{
        color: ' . $heading_color . ';
    }

    .pagination .nav-links .current{
        background: ' . $link_hover_color . ' !important;
    }

    .top-menu .navigation > li > a:hover {
    	color: ' . $link_hover_color . ';
    }

    .top-menu .navigation > li:last-child a:hover {
        background: ' .$button_hover_bg_color . ';
    }

    .top-menu .navigation > li > a:hover {
        color: ' . $site_menu_hover_color . ';
    }

    .top-menu .navigation > li > a {
        color: ' . $site_menu_color . ';
    }

    .top-menu .navigation > li:last-child a{
        color: ' . $button_text_color . ';
    }
    .content-section {
    background: ' .$page_background_breadcrumbs_color . ';
    }

    .page-title .main-title, 
    .page-title span ,
    .page-title .breadcrumbs li:after {
        color: ' . $page_title_breadcrumbs_color .';
    }
    
    .footer-copyrights-wrapper {
    margin-top: ' . $footer_copyright_text . 'px;
    width: auto;
    }

    footer#footer,
    .footer-widgets-wrapper .widget-column {
        background-color: '. $footer_bg_color .';
    }

    .footer-widgets-wrapper .widget-column a,
    .footer-widgets-wrapper .widget-title,
    .footer-widgets-wrapper caption,
    footer#footer{
        color: ' .$footer_content_color .';
    }

    .footer-copyrights-wrapper .copyright a{
        color: ' .$footer_links_color .';
    }

    .footer-widgets-wrapper {
        margin-top: ' . $footer_section_spacing .'px;
    }

    .footer-widgets-wrapper .widget-column {
        padding: 0 ' . $footer_column_spacing .'px;
    }

    form.wpcf7-form input,
    form.wpcf7-form textarea,
    form.wpcf7-form radio,
    form.wpcf7-form checkbox{
        border: 1px solid #d0d0d0;
        color: #555;
    }

    form.wpcf7-form input::placeholder,
    form.wpcf7-form textarea::placeholder{
        color: #555;
    }

    form.wpcf7-form input[type="submit"]{
        color: #fff;
    }

    form.wpcf7-form label{
        color: #555;
    }

    button.navbar-toggle,
    button.navbar-toggle:hover{
        background: none !important;
        box-shadow: none;
    }

    .menu-social li a{
        color: ' . $link_color . ';
    }

    .menu-social li a:hover{
        color: ' . $link_hover_color . ';
    }

    aside h4.widget-title:hover{
        color: inherit;
    }

    .single h1.entry-title a,
    .cat-item a,
    .latest-posts-area-content a{
        color: #555;
        transition: all 0.3s ease-in-out;
    }

    .cat-item a:hover,
    .latest-posts-area-content a:hover,
    .layout-1-area-content .title h3 a:hover{
        color: #000;
        transition: all 0.3s ease-in-out;
    }

    .single article .title, 
    .single article .content,
    .single article #comments {
        width: ' . $single_post_width . '%;
        min-width: auto;
    }

    .single article p {
        width: 100%;
    }

    .container {
	    width: 95%;
	    margin: 0 auto;
	}

';

// Page title align menu to left
if(true===get_theme_mod('legalblow_enable_page_title_left',true) && true===get_theme_mod('legalblow_enable_page_title_left',true)){
        $css .='
        .page-title .main-title {
            text-align:left;
        }
        ';
}

else{

}

//Show Page Title background

    if(true===get_theme_mod('legalblow_enable_page_title_bg',true) && true===get_theme_mod('legalblow_enable_page_title_bg',true)){
        $css .='
        .content-section {
            background: ' .$page_background_breadcrumbs_color. ';
        }
        ';
}

else{
    $css .='
    .content-section {
        background: none;
    }
    ';
}

// Align menu to right
if(true===get_theme_mod('legalblow_enable_header_menu_align',true) && true===get_theme_mod('lbpa_menu_cart',true)){
            $css .='
            .top-menu-wrapper{
            float: right;
            }
            
            ';
}

else{

}



// //Show last menu item as button`

if(true===get_theme_mod( 'legalblow_enable_header_menu_last_button',true)){
    if('square'===esc_html(get_theme_mod( 'legalblow_choose_style_menu_last_button','square'))){

        $css .=' 

            .top-menu .navigation > li:last-child a {
                background: '.$button_bg_color.';
                color: '.$button_text_color.';
                margin: 4px 0 0 0;
                padding: 10px 75px;
            }
            .top-menu .navigation > li:last-child{
                float:right;
            }
        ';                                                                                                        
        }

        else{
            $css .=' 
            .top-menu .navigation > li:last-child a {
                border: 1px solid '.$button_bg_color.';
                color:'.$button_text_color.';
                margin: 4px 0 0 0;
                padding: 10px 75px;
            }
            .top-menu .navigation > li:last-child{
                float:right;
            ';
        }
        }
    else{
        $css .=' 

        .top-menu .navigation > li:last-child a {
            background:none;
            color: '.$site_menu_color.';
        }
        .top-menu .navigation > li:last-child a:hover{
            background:none;
            color:'.$site_menu_hover_color.';
        }
    ';       
    }

         

if(false===get_theme_mod( 'legalblow_display_site_title_tagline',true)){
    $css .='
        h1.site-title,
        p.site-description{
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_footer_copyright_text',true)){
    $css .='
    footer-copyrights-wrapper{
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_posts_cat',true)){
    $css .='
        ul.post-categories {
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_posts_meta_date',true)){
    $css .='
        span.separator,
        span.date {
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_posts_meta_author',true)){
    $css .='
        span.author,
        span.by{
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_posts_meta_comments',true)){
    $css .='
        span.comments{
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_single_post_cat',true)){
    $css .='
        .single div.post-categories {
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_single_post_tags',true)){
    $css .='
        .single div.post-tags {
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_single_post_meta_date',true)){
    $css .='
        .single span.date-single {
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_single_post_meta_author',true)){
    $css .='
        .single span.author-single {
        	display: none;
        }
    ';
}

if(false===get_theme_mod( 'legalblow_enable_single_post_meta_comments',true)){
    $css .='
        .single span.comments-single {
        	display: none;
        }
    ';
}

if('both-sidebars'===esc_html(get_theme_mod('legalblow_home_page_layout','both-sidebars'))) {
    if ( is_active_sidebar( 'legalblow-hp-left-section' ) && is_active_sidebar( 'legalblow-hp-right-section' ) ) {
        $css .='
	        .both-sidebars .container {
	        	width: 90%;
	        	margin: 0 auto;
	        }
	    ';   
    }
    $css .='
        .home.elementor-page.both-sidebars .container {
        	width: 90%;
        	margin: 0 auto;
        }

        .home.elementor-page.both-sidebars .elementor-section.elementor-section-boxed>.elementor-container {
        	width: 90% !important;
        	max-width: 90% !important;
        }
    ';
}

if('no-sidebars'===esc_html(get_theme_mod('legalblow_home_page_layout','both-sidebars'))) {
    if ( is_active_sidebar( 'legalblow-hp-left-section' ) && is_active_sidebar( 'legalblow-hp-right-section' ) ) {
        $css .='
	        .no-sidebar .container {
	        	width: 90%;
	        	margin: 0 auto;
	        }
	    ';   
    }
    $css .='
        .home.elementor-page.no-sidebar .container {
        	width: 90%;
        	margin: 0 auto;
        }

        .home.elementor-page.no-sidebar .elementor-section.elementor-section-boxed>.elementor-container {
        	width: 90% !important;
        	max-width: 90% !important;
        }
    ';
}

if(true===get_theme_mod( 'legalblow_enable_single_post_full_width',false)){
    $css .='
        .single .title, 
        .single .content,
        .single #comments {
        	width: 100%;
        	margin: 0 auto;
        }
    ';
}


if(true===get_theme_mod( 'legalblow_enable_single_page_title_section',true)){
    $css .='
    ';
    }
    else{
    $css .='
    .single .img-overlay{
        	display:none;
        }
    ';
    }

if(true===get_theme_mod( 'legalblow_enable_single_page_title',true)){
    $css .='
    ';
    }
    else{
    $css .='
    .single .img-overlay .section-title .main-title{
        	display:none;
        }
    ';
    }

// check it;'s not a homepage
if(!is_front_page()):
    $css .='
        .blog .content-inner ,
        .content-page {
            margin-top: ' . $page_content_spacing_top_title . 'px;
        }

        .page #sidebar-wrapper {
            margin-top: ' . $page_content_spacing_top_title . 'px !important;
        }

        .page-title .content-section {
            padding-top: ' . $page_title_spacing_top . 'px;
            padding-bottom: ' . $page_title_spacing_bottom . 'px;
        }
    ';
endif;


/* check if header transparent enable and page title disabled */
if(true===get_theme_mod( 'legalblow_enable_header_transparent',false) && false===get_theme_mod( 'legalblow_enable_page_title',true)) :
    $blog_bg_color= sanitize_hex_color(get_theme_mod( 'legalblow_blog_bg_color','#ca2e49' ));
    $css .='
        .blog .page-title .content-section,
        .single .page-title .content-section, 
        .archive .page-title .content-section, 
        .author .page-title .content-section,
        .search .page-title .content-section, 
        .error404 .page-title .content-section {
           display:none;
         }

        .blog .page-title h1, 
        .single .page-title h1, 
        .archive .page-title h1, 
        .author .page-title h1,
        .search .page-title h1, 
        .error404 .page-title h1 {
            padding-top: 0;
        }

        .page .content-inner {
            margin-top: 70px;
            margin-bottom: 70px;
        }
    ';

endif;


//content width settings//
if( 1170 != absint(get_theme_mod( 'legalblow_layout_content_width_settings','1170'))) :
    $css .='
         @media (min-width: 1000px) {
            .container {
                width: ' . $layout_content_width . 'px ;
            }
        }
    ';
endif;


//sticky header logo
if ( get_theme_mod( 'legalblow_enable_logo_stickyheader', false )) :
	$css .='
		#header-main.sticky .logo a.logo-alt img {
			max-height: 65px;
			width: auto !important;
		}
	';
endif;


//check if center copyrights text
if(true===get_theme_mod( 'legalblow_enable_center_copyrights_text',true)) :
    $css .='
    .copyright p, .copyright span, .copyright span a{
            padding:0;
         }
    ';
endif;

if (true === get_theme_mod('legalblow_enable_single_page_heading', true)) {
    $css .= '.title {
        display: block; 
    }';
} 

else {
    $css .= '.title {
        display: none;
    }';
}
    


//check if single page post text is align to center
if(true===get_theme_mod( 'legalblow_enable_single_post_align_center',false)) :
    $css .='
        .single article .title, 
        .single article .content,
        .single article #comments {
            margin: 0 auto;
        }

        .single .blog-post .image {
            text-align: center;
        }
    ';
endif;

// breadcrumb enable
if( true === get_theme_mod( 'legalblow_enable_page_breadcrumbs',true)) {
    $css .='

        .page-title h1 {
            padding-bottom: 0;
        }

        .page-title #breadcrumbs {
            margin-top: 10px;
            margin-bottom: 30px;
        }

        .page-title span {
            display: inline-block;
            margin-top: 5px;
            margin-bottom: 15px;
        }

        .page-title .breadcrumbs li {
            display: inline-block;
            padding: 0 3px;
        }

        .page-title .breadcrumbs li:after {
            content: ">";
            display: inline-block;
        }

        .page-title .breadcrumbs li:last-child::after {
            display: none;
        }

        .page-title .breadcrumbs li a {
            padding-left: 10px;
            vertical-align: inherit;
        }

        .page-title .breadcrumb-wrapper span a {
            vertical-align: inherit;
        }

        .page-title h1 {
            padding-bottom: 0;
        }

        .page-title span {
            display: inline-block;
            margin-top: 5px;
            margin-bottom: 15px;
        }
    ';
}

/* Preloader */
if(true === get_theme_mod( 'legalblow_enable_preloader',false )) :
    $css .='

        .loader-wrapper {
            background: #fff;
            width: 100%;
            height: 100%;
            position: fixed !important;
            top: 0;
            bottom: 0;
            left: 0;
            right: 0;
            z-index: 100000;
        }

        #pre-loader {
            height: 30px;
            width: 30px;
            position: absolute;
            top: 45%;
            left: 47%;
        }

        .loader-pulse {
            width: 50px;
            height: 50px;
            background-color: #555;
            border-radius: 100%;
            animation: loader-pulse 1.2s infinite cubic-bezier(0.455, 0.03, 0.515, 0.955); 
        }

        @keyframes loader-pulse {
            0% {
                transform: scale(0); 
            } 100% {
                transform: scale(1);
                opacity: 0; 
            }
        }

    ';
endif;


return apply_filters( 'legalblow_dynamic_css_stylesheet', legalblow_minimize_css($css));

}

