<?php
/**
 * @package legalblow
 */


/**
 * Header
 */

 if ( ! function_exists( 'legalblow_header_menu_styles' ) ) :
function legalblow_header_menu_styles() {
    get_template_part( 'inc/header-menu/content',esc_html(get_theme_mod('legalblow_header_menu_styles','style1')));
}
endif;
add_action( 'legalblow_action_header', 'legalblow_header_menu_styles' );

/**
 * Page Title Settings
 */
if (!function_exists('legalblow_show_page_title')):
    function legalblow_show_page_title( $blogtitle=false,$archivetitle=false,$searchtitle=false,$pagenotfoundtitle=false ) {
        if(!is_front_page()){
            if ('color' === esc_html(get_theme_mod( 'legalblow_page_bg_radio','color' ))) {
                ?>
                    <div class="page-title" style="background:<?php echo sanitize_hex_color(get_theme_mod( 'legalblow_page_bg_color','' )); ?>;">
                <?php
            }
            else if('image' === esc_html(get_theme_mod( 'legalblow_page_bg_radio','color' ))){
                $image= esc_url(get_template_directory_uri().'/img/start-bg.jpg');
                ?>

                    <?php
                        if(true===get_theme_mod( 'legalblow_page_bg_parallax',true)) {
                            if ( has_post_thumbnail()) {
                                $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');

                                ?>
                                    <div class="page-title" data-parallax="scroll" data-image-src="<?php echo esc_url($featured_img_url); ?>">  
                                <?php
                            }
                            else{
                                ?>
                                    <div class="page-title" data-parallax="scroll" data-image-src="<?php echo esc_url($image ); ?>">
                                <?php   
                            }
                        }
                        else{
                            if ( has_post_thumbnail()) {
                                $featured_img_url = get_the_post_thumbnail_url(get_the_ID(),'full');
                                ?>
                                    <div class="page-title" style="background:url('<?php echo esc_url($featured_img_url) ?>') no-repeat scroll center center / cover;"> 
                                <?php
                            }
                            else{
                                ?>
                                    <div class="page-title"  style="background:url('<?php echo esc_url($image ); ?>') no-repeat scroll center center / cover;">    
                                <?php   
                            }
                        }
                    ?>
                    
                <?php
            }
            else{
                ?>
                    <div class="page-title" style="background:#a2824d;"> 
                <?php
            }
            
            ?>
                
                <div class="content-section img-overlay">
                    <div class="container">
                        <div class="row text-center">
                            <div class="col-md-12">
                                <div class="section-title page-title"> 
                                    <?php
                                        if($blogtitle){
                                            ?><h1 class="main-title"><?php single_post_title(); ?></h1><?php
                                        }
                                        if($archivetitle){
                                            ?><h1 class="main-title"><?php the_archive_title(); ?></h1><?php
                                        }
                                        if($searchtitle){
                                            ?><h1 class="main-title"><?php esc_html_e('SEARCH RESULTS','legalblow') ?></h1><?php
                                        }
                                        if($pagenotfoundtitle){
                                            ?><h1 class="main-title"><?php esc_html_e('PAGE NOT FOUND','legalblow') ?></h1><?php
                                        }                                       
                                        
                                        if($blogtitle==false && $archivetitle==false && $searchtitle==false && $pagenotfoundtitle==false){
                                            ?><h1 class="main-title"><?php the_title(); ?></h1><?php
                                        }
                                    ?>
                                    <div class="breadcrumb-wrapper">
                                        <?php 
                                            if(get_theme_mod( 'legalblow_enable_page_breadcrumbs',true)) :
                                                $breadcrumb_from = esc_html(get_theme_mod( 'legalblow_page_breadcrumb_select_radio','default'));
                                                if (function_exists('yoast_breadcrumb') && $breadcrumb_from == 'yoast') :
                                                    yoast_breadcrumb('<p id="breadcrumbs">','</p>');
                                                elseif (function_exists('bcn_display') && $breadcrumb_from == 'navxt'): 
                                                    bcn_display();
                                                else:
                                                    require get_template_directory() . '/inc/breadcrumbs.php';
                                                    $breadcrumb_args = array(
                                                        'container' => 'div',
                                                        'show_browse' => false
                                                    );        
                                                    breadcrumb_trail($breadcrumb_args);
                                                endif;
                                            endif;
                                        ?>
                                    </div>                                                         
                                </div>                      
                            </div>
                        </div>
                    </div>  
                </div>
                </div>  <!-- End page-title --> 
            <?php
        }
    }
endif;
add_action('legalblow_get_page_title', 'legalblow_show_page_title');

/**
 * Footer
 */

 if ( ! function_exists( 'legalblow_footer_copyrights' ) ) :
function legalblow_footer_copyrights() {
    ?>
        <div class="row">
            <div class="copyright">
                <p>
                    <?php 

                        if("" != esc_html(get_theme_mod( 'legalblow_footer_copyright_text'))) {
                            echo esc_html(get_theme_mod( 'legalblow_footer_copyright_text'));
                            if(get_theme_mod('legalblow_en_footer_credits',true)) {
                                ?><span><?php esc_html_e(' | Theme by ','legalblow') ?><a href="<?php echo esc_url(LEGALBLOW_THEME_AUTH); ?>" target="_blank"><?php esc_html_e('Spiracle Themes','legalblow') ?></a></span>
                                <?php 
                            }
                        }
                        else{
                            echo date_i18n(
                                /* translators: Copyright data format, see https://secure.php.net/date */
                                    _x( 'Y', 'copyright date format', 'legalblow')
                                );
                                ?>
                                <a href="<?php echo esc_url( home_url( '/' ) ); ?>"><?php bloginfo( 'name' ); ?></a>
                                <span><?php esc_html_e(' | Theme by ','legalblow') ?><a href="<?php echo esc_url(LEGALBLOW_THEME_AUTH); ?>" target="_blank"><?php esc_html_e('Spiracle Themes','legalblow') ?></a></span>

                                <?php 
                            }
                        ?>
                    </p>
                </div>
            </div>
        <?php 
    }
endif;
add_action( 'legalblow_action_footer', 'legalblow_footer_copyrights' );

/**
 * Custom excerpt length.
 */
if ( ! function_exists( 'legalblow_excerpt_length' ) ) :
function legalblow_excerpt_length($length) {
    if ( is_admin() ) {
        return $length;
    }
    return absint(get_theme_mod('legalblow_posts_excerpt_length',20));
}
endif;

add_filter('excerpt_length', 'legalblow_excerpt_length');

/**
 * Category list
 */

 if( !function_exists( 'legalblow_category_list' ) ):
    function legalblow_category_list() {
        $pm_args = array(
            'type'      => 'post',
            'taxonomy'  => 'category',
        );
        $pm_cat_lists = get_categories( $pm_args );
        $pm_cat_list = array('' => esc_html__('--Select--','legalblow'));
        foreach( $pm_cat_lists as $category ) {
            $pm_cat_lists[esc_html( $category->slug )] = esc_html( $category->name );
        }
        return  $pm_cat_list;
    }
endif;


/**
 * Get Page Title
 */

 if( !function_exists( 'legalblow_get_title' ) ):
    function legalblow_get_title() {
        if(!is_front_page()) :
            ?>
                <div class="page-title">
                    <h1 class="main-title"><?php the_title(); ?></h1>
                </div>
            <?php 
        endif;
    }
endif;


/**
 * Adding single sidebar classes to body
 */
if ( ! function_exists( 'legalblow_add_blog_single_sidebar_classes_to_body' ) )  :
function legalblow_add_blog_single_sidebar_classes_to_body($classes = '') {
    if('right'===esc_html(get_theme_mod('legalblow_blog_single_sidebar_layout','no'))) {
        $classes[] = 'single-right-sidebar';
    }
    else if('left'===esc_html(get_theme_mod('legalblow_blog_single_sidebar_layout','no'))){
        $classes[] = 'single-left-sidebar';
    }
    else{
        $classes[] = 'single-no-sidebar';
    }
    return $classes;
}
endif;
add_filter('body_class', 'legalblow_add_blog_single_sidebar_classes_to_body');


/**
 * Adding blog sidebar classes to body
 */
if ( ! function_exists( 'legalblow_add_blog_sidebar_classes_to_body' ) )  :
function legalblow_add_blog_sidebar_classes_to_body($classes = '') {
    if('right'===esc_html(get_theme_mod('legalblow_blog_sidebar_layout','right'))) {
        $classes[] = 'blog-right-sidebar';
    }
    else if('left'===esc_html(get_theme_mod('legalblow_blog_sidebar_layout','right'))){
        $classes[] = 'blog-left-sidebar';
    }
    else{
        $classes[] = 'blog-no-sidebar';
    }
    return $classes;
}
endif;
add_filter('body_class', 'legalblow_add_blog_sidebar_classes_to_body');




/**
 * Preconnect Fonts
 */
function legalblow_preconnect_fonts() {
    ?>
        <link rel="dns-prefetch" href="https://fonts.gstatic.com"> 
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin="anonymous">
    <?php
}
add_action( 'wp_head', 'legalblow_preconnect_fonts' );


/**
 * Search Form
 */
if ( ! function_exists( 'legalblow_search_content' ) ) :
function legalblow_search_content() {
    ?>
        <div class="search-form-wrapper">
            <form method="get" class="searchform" action="<?php echo esc_url(home_url('/')); ?>">
                <div class="form-group-search">
                    <label class="screen-reader-text" for="searchsubmit"><?php esc_html_e('Search for:', 'legalblow'); ?></label>
                    <input type="search" id="pm-search-field" class="search-field" placeholder="<?php esc_attr_e('Search here','legalblow') ?>" value="<?php echo get_search_query(); ?>" name="s"/>
                    <button type="submit" value=""><?php esc_html_e('Search','legalblow') ?></button>
                </div>
            </form>
        </div>
    <?php 
}
endif;
add_action('legalblow_action_search_content', 'legalblow_search_content');


/**
 * Left Modal
 */
if ( ! function_exists( 'legalblow_left_modal_content' ) ) :
function legalblow_left_modal_content() {
    ?>
        <div class="modal left fade" id="pmModal" tabindex="-1" role="dialog" aria-labelledby="pmModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true"><i class="fas fa-times"></i></span></button>
                    </div>  
                    <div class="modal-body">
                        <aside id="menuleftsidebar" class="widget-area" role="complementary">
                            <?php 
                                if ( is_active_sidebar('menuleftsidebar')) {
                                    dynamic_sidebar('menuleftsidebar');
                                }
                            ?>
                        </aside>
                    </div>
                </div>
            </div>
        </div>
    <?php 
}
endif;
add_action('legalblow_action_left_modal_content', 'legalblow_left_modal_content');


/**
 * Function for storing activation time
 */
function legalblow_activation_time() {
    if ( false === get_option( 'legalblow_activation_time' ) ) {
        add_option( 'legalblow_activation_time', strtotime('now') );
    }
}
add_action( 'after_switch_theme', 'legalblow_activation_time');
add_action('after_setup_theme', 'legalblow_activation_time');


/**
 * Function for Minimizing dynamic CSS
 */
function legalblow_minimize_css($css){
    $css = preg_replace('/\/\*((?!\*\/).)*\*\//', '', $css);
    $css = preg_replace('/\s{2,}/', ' ', $css);
    $css = preg_replace('/\s*([:;{}])\s*/', '$1', $css);
    $css = preg_replace('/;}/', '}', $css);
    return $css;
}


/**
 * Adding class to body
 */
if ( ! function_exists( 'legalblow_add_classes_to_body' ) ) :
function legalblow_add_classes_to_body($classes = '') {
    $classes[] = 'theme-legalblow';
    return $classes;
}
endif;
add_filter('body_class', 'legalblow_add_classes_to_body');


/**
 * Function for changing category archive title
 */
function legalblow_get_archive_title($title) {
    if ( is_category() ) {
        $title_text = esc_html(get_theme_mod( 'legalblow_cat_archive_title_text', esc_html__('Category:','legalblow'))). " ";
        $title = single_cat_title($title_text);
    }
    return $title;
}
if(true===get_theme_mod( 'legalblow_enable_cat_archive_settings',false)) :
    add_filter( 'get_the_archive_title', 'legalblow_get_archive_title');
endif;


/**
 * Disable Plugin Redirect
 */
function legalblow_prevent_plugins_redirect() {
    delete_transient( 'elementor_activation_redirect');
}
add_action('admin_init', 'legalblow_prevent_plugins_redirect');