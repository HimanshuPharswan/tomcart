
  (function ($) {

    $(document).ready(function () {
    });    

})(this.jQuery);