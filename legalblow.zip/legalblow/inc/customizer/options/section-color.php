<?php
/**
 * Theme Customizer Controls
 *
 * @package legalblow
 */


if ( ! function_exists( 'legalblow_customizer_color_register' ) ) :
function legalblow_customizer_color_register( $wp_customize ) {
 
 	$wp_customize->add_section(
        'legalblow_color_settings',
        array (
            'priority'      => 25,
            'capability'    => 'edit_theme_options',
            'title'         => esc_html__( 'Color Settings', 'legalblow' )
        )
    );

    // Title label
	$wp_customize->add_setting( 
		'legalblow_label_color_settings_title', 
		array(
		    'sanitize_callback' => 'legalblow_sanitize_title',
		) 
	);

	$wp_customize->add_control( 
		new LegalBlow_Title_Info_Control( $wp_customize, 'legalblow_label_color_settings_title', 
		array(
		    'label'       => esc_html__( 'Colors', 'legalblow' ),
		    'section'     => 'legalblow_color_settings',
		    'type'        => 'legalblow-title',
		    'settings'    => 'legalblow_label_color_settings_title',
		) 
	));

	// Menu color
    $wp_customize->add_setting(
        'legalblow_site_menu_color',
        array(
            'type' => 'theme_mod',
            'default'           => '#ffffff',
            'sanitize_callback' => 'sanitize_hex_color'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
        	$wp_customize,
        	'legalblow_site_menu_color',
	        array(
	        	'label'      => esc_html__( 'Menu Color', 'legalblow' ),
	        	'section'    => 'legalblow_color_settings',
	        	'settings'   => 'legalblow_site_menu_color',
	        )
	    )
	);

	// Menu hover color
    $wp_customize->add_setting(
        'legalblow_site_menu_hover_color',
        array(
            'type' => 'theme_mod',
            'default'           => '#0A0000',
            'sanitize_callback' => 'sanitize_hex_color'
        )
    );

    $wp_customize->add_control(
        new WP_Customize_Color_Control(
        	$wp_customize,
        	'legalblow_site_menu_hover_color',
	        array(
	        	'label'      => esc_html__( 'Menu Hover Color', 'legalblow' ),
	        	'section'    => 'legalblow_color_settings',
	        	'settings'   => 'legalblow_site_menu_hover_color',
	        )
	    )
	);
}
endif;

add_action( 'customize_register', 'legalblow_customizer_color_register' );